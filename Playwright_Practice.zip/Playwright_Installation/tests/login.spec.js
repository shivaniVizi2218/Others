const { test, expect } = require('@playwright/test');

test('has login', async({page}) => {
    await test.step('launching url',async() =>{
        await page.goto('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login');

    }) 
    await test.step('Expecting orangehrm branding visible or not', async()=>{
        await expect(page.locator('//div[@class="orangehrm-login-branding"]')).toBeVisible();

    })
    await test.step('Checking whether required text present or not', async() =>{
        await expect(page.locator("//h5[text()='Login']")).toHaveText('Login');

    })
    await expect(page.locator("//h5[text()='Login']")).toContainText('Log');

    await page.locator("//input[@name='username']").fill('Admin');
    await page.locator("//input[@name='password']").fill('admin123');
    await page.locator("//button[@type='submit']").click();
    await page.waitForTimeout(3000);
    
})
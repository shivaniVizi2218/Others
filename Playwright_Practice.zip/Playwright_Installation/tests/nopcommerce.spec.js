const {test,expect} = require('@playwright/test')

const nopData = require('../data/nopCommerceData.json')
const {pageHome} = require('../pages/nop_homePage')
const {pageLogin} = require('../pages/nop_loginpage')
const { executeStep } = require('../utilities/actions')


test('launching nopcommerce', async({page}) => {
    const home = new pageHome(page);
    await home.lanchingApplication();


})































 
// test('home page validations', async({page}) => {
//     const home = new pageHome(page);
//     const loginvar = new pageLogin(page);
//     await page.goto(nopData.login.loginURL);
//     await expect(home.register).toBeVisible();
//     await expect(loginvar.log).toBeVisible();
//     await loginvar.log.click();
//     await page.waitForTimeout(3000);

// })

// test('login validation', async({page}) => {
    

// })
const{test} = require('@playwright/test')

const data = require('../data/loginData.json')

const{LoginPage} = require('../pages/login')


test('has login', async ({ page }) => {
    
    await page.goto(data.login.loginURL)

    const varLogin = new LoginPage(page)

    await varLogin.userNameFirst.fill(data.login.userName)

    await varLogin.passwordFirst.fill(data.login.password)

    await varLogin.submitBtn.click()

    await page.waitForTimeout(3000)
});


import { test, expect } from '@playwright/test';

test('test', async ({ page }) => {
  await page.goto('https://www.google.com/search?q=w3schools&oq=w3schools&aqs=chrome..69i57.5522j0j2&sourceid=chrome&ie=UTF-8');
  await page.getByRole('link', { name: 'W3Schools Online Web Tutorials W3Schools https://www.w3schools.com' }).click();
  await page.getByPlaceholder('Search our tutorials, e.g. HTML').click();
  await page.getByPlaceholder('Search our tutorials, e.g. HTML').fill('java');
  await page.getByPlaceholder('Search our tutorials, e.g. HTML').press('Enter');
  await page.goto('https://www.w3schools.com/');
  await page.getByPlaceholder('Search our tutorials, e.g. HTML').click();
  await page.getByPlaceholder('Search our tutorials, e.g. HTML').fill('java');
  await page.getByRole('button', { name: '' }).click();
});
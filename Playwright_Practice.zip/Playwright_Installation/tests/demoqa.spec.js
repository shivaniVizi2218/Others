const {test} = require('@playwright/test');

require("dotenv").config();

test('demo', async ({ page }) => {

    await test.step( "Launching the main URL" , async() => {
        await page.goto("https://demoqa.com/")
    })

    await test.step( "Clicking the Element card", async() => {
        await page.locator( '//h5[text()="Elements"]').click()
    })

    await test.step( "Clicking Text Box", async() => {
        await page.locator( "//*[text()='Text Box']").click()
    })

    await test.step("Typing the full name", async() => {
        await page.locator( '//input[@id="userName"]').type(process.env.fullname)
    })

    await test.step( "Clicking Check Box" , async() => {
        await page.locator( "//*[text()='Check Box']").click()
    })

    await test.step( "Checking whether check-box got selected or not", async() => {
        await page.locator("//input//following::span[text()='Home']").check();
    })

    await test.step( "Unchecking the check-box", async() => {
        await page.locator("//input//following::span[text()='Home']").uncheck();
        await page.waitForTimeout(3000)
    })
   

});

const{test} = require('@playwright/test')

test('has subscribe details', async({page}) => {
    await test.step('Launching URL', async() => {
        await page.goto('https://tinbuilding.com/')
     })
    await test.step('', async() => {
        await page.locator('//input[@id="mcfirstName"]').fill("renu")
     })
    await test.step('Entering the Email Address',async()=>{
        await page.locator('//input[@id="mcemail"]').fill("rs@vinu.com")
    })

    await test.step('Entering the Zipcode',async()=>{
        await page.locator('//input[@id="mczipcode"]').fill("53003")
        await page.waitForTimeout(5000);
    })
    await test.step('clicking on dropdown',async()=>{
        await page.locator('//div[@class="dropdown-heading"]').click();
        await page.selectOption('select[class="dropdown-content"]', { label: 'Dining' });

   })

  


})
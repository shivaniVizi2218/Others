const { test, expect } = require('@playwright/test');

//const data = require('../data/loginData.json');

require("dotenv").config();

test.skip('has login', async ({ page }) => {
    
    await page.goto(data.login.loginURL);
    await page.locator("//input[@name='username']").fill(data.login.userName);
    await page.locator("//input[@name='password']").fill(data.login.password);
    await page.locator("//button[@type='submit']").click();
    await page.waitForTimeout(3000);
    
});

test('login', async ({ page }) => {

    await page.goto(process.env.base_url);
    await page.locator("//input[@name='username']").fill(process.env.base_username);
    await page.locator("//input[@name='password']").fill(process.env.base_password);
    await page.locator("//button[@type='submit']").click();
    await page.waitForTimeout(3000);
 
})
 
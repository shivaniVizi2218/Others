import { test, expect } from '@playwright/test';

test('test', async ({ page }) => {
    await page.goto('https://www.myntra.com/');
    await page.getByPlaceholder('Search for products, brands and more').fill('shoes');
   // await page.waitForTimeout(3000);
    await page.getByRole('textbox',{class:'desktop-searchBar'}).fill('Shivani');
   // await page.waitForTimeout(3000);
    await page.locator('.desktop-searchBar').fill('Vinu');
   // await page.waitForTimeout(2000);
    await page.locator("//div[@class='desktop-navLink']//child::a[text()='Studio']").click();
   /* await page.locator('//span[contains(text(),"Profile")]').click();
    await page.waitForTimeout(2000);*/


});

test.only('has profile',async({page}) => {
   await page.goto('https://www.myntra.com/');
   await page.locator('//span[contains(text(),"Profile")]').click();
   //await page.waitForTimeout(2000);
   await page.locator("//a[starts-with(text(),'login')]").click();
   await page.locator('//*[@class="form-control mobileNumberInput"]').fill('8367622693');
   await page.locator("//*[contains(@class,'submitBottomOption')]").click();
   await page.waitForTimeout(5000);
});
const {test} = require('@playwright/test')
const {HomePage} = require('../pages/tb_homepage')

test('has shop-market details', async({page}) => {
    const pageHome = new HomePage(page)
    await page.goto("https://tinbuilding.com/")
    await pageHome.shopmarket.hover()
    await pageHome.mercato.click();
    await await page.waitForTimeout(2000);
    await page.locator("(//div[@role='document'])[5]/descendant::button[@aria-label='Close']").isVisible();
    await page.locator('//div[@id="ZipEmailModal"]//button').hover()
  //  page.on('dialog', async (dialog) => {
        // Dismiss the dialog (close the pop-up)
     //   await dialog.dismiss();
      
    await page.locator(`//a[@aria-label="Sign in to your account"]`).click()
    await page.locator(`//label[text()='Email address']`).fill('rsv111099@gmail.com')
    await page.locator(`//input[@type="password"]`).fill('Renu1110')
   // await pageHome.sample.click()
    
});
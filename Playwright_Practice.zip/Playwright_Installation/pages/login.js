exports.LoginPage = class LoginPage {

    constructor(page) {

        this.page = page;
        
        this.userNameFirst = page.locator("//input[@name='username']");
        this.passwordFirst = page.locator("//input[@name='password']");
        this.submitBtn = page.locator("//button[@type='submit']");

    }

}
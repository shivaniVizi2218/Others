exports.HomePage = class HomePage {
    constructor(page){
        this.page = page
        this.shopmarket = page.locator("//span[text()='SHOP MARKET']")
        this.mercato = page.locator("//span[text()='MERCATO']")
        this.sample=page.locator(`(//div[contains(@class,'product-carousel')])[2]/descendant::a[contains(.,'Organic Black Bell Pepper')][1]/ancestor::div[@data-target="#manufactured-modal"]`)
    }
}
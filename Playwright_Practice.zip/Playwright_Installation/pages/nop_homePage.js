const { executeStep } = require('../utilities/actions')
const nopData = require('../data/nopCommerceData.json')


exports.pageHome = class pageHome{
    constructor(page,test){
        this.page = page;
        this.test = test;
        this.register = page.locator("//a[text()='Register']");
        this.log = page.locator("//a[text()='Log in']");
        this.searchbar = page.locator("//input[@name='q']");
        this.btnSearch = page.locator("//button[text()='Search']");
        this.success = page.locator("//div[contains(@class,'success')]");
        this.close = page.locator("//div[contains(@class,'success')]/span");
    }

    async lanchingApplication(){
        await executeStep(this.test,await this.page,"navigate",
        `Navigating to ${nopData.login.loginURL}`,  [nopData.login.loginURL]
        )
    }
}



const { executeStep } = require('../utilities/actions')

exports.pageLogin = class pageLogin{
    constructor(page){
        this.page = page;
        this.email = page.locator("//input[@id='Email']");
        this.pswd = page.locator("//input[@id='Password']");
        this.btnLogin = page.locator("//button[text()='Log in']")
    }
}